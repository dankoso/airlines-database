#Variable and list names:

#Admin info (examples): Jason - 21344, Edensio - 23143


#Searches within json database given data.
#print(json.dump(z))
    
#Local variables
#Dataentry = ['' in range(3)]
#Datatype = ("Company name", "IATA", "ICAO")

#Algorithm
#print("Search by company name, IATA, and/or ICAO code. ")
#for i in range(3):
#    print("Enter", Datatype[i], "data: ", end = " ")
#    Dataentry[i] = input()
import json

database = {
    'Airline1' : {
        'codes': ["CO","SH"],
        'callsign': 'Squeaky',
        'type_of_plane': ['type1', 'type2'],
        'type_of_airline': 'Scheduled',
        'number_of_planes': 3,
    },
   'Airline2' : {
        'codes': ["GK","S2"],
        'callsign': 'Sexy',
        'type_of_plane': ['type3', 'type4'],
        'type_of_airline': 'Chartered',
        'number_of_planes': 5,
    },
}

def write_json(new_data, filename = 'logs.json'):
    with open(filename,'r+') as file:
        file_data = json.load(file)
        file_data["user_logs"].append(new_data)
        file.seek(0)
        json.dump(file_data, file, indent = 4)

def find_total_airline(airline):
    if airline in database:
            print("Planes in fleet:", database[airline]['number_of_planes'])

def find_type_planes(airline):
    if airline in database:
        print("Fleet type:", database[airline]['type_of_plane'])

def find_airline_code(airline):
    if airline in database:
        print("Airline codes: \nIATA:", database[airline]['codes'][0], "\nICAO:", database[airline]['codes'][1])

def find_type_airline(airline):
    print("Airline type: ", database[airline]['type_of_airline'])

def find_airline_callsign(airline):
    print("Callsign: ", database[airline]['callsign'])

def find_by_airline(airline):
    if airline in database:
        print("\nYour search found", airline + "!\n")
        find_airline_code(airline)
        find_airline_callsign(airline)
        find_type_airline(airline)
        find_total_airline(airline)
        find_type_planes(airline)
        

def find_by_iata(iatacode):
    for airline in database:
        if iatacode == database[airline]['codes'][0]:
            print("\nYour search found", airline + "!\n")
            find_airline_code(airline)
            find_airline_callsign(airline)
            find_type_airline(airline)
            find_total_airline(airline)
            find_type_planes(airline)

def find_by_icao(icaocode):
    for airline in database:
        if icaocode == database[airline]['codes'][1]:
            print("\nYour search found", airline + "!\n")
            find_airline_code(airline)
            find_airline_callsign(airline)
            find_type_airline(airline)
            find_total_airline(airline)
            find_type_planes(airline)            

def searchtype(Dataentry):
    if Dataentry[0] in database:
        find_by_airline(Dataentry[0])
    elif Dataentry[1] != "":
        find_by_iata(Dataentry[1])
    elif Dataentry[2] != "":
        find_by_icao(Dataentry[2])
    else:
        print("Invalid input.")

def print_output(return_dict):
    for key in return_dict:
        print(f"{key}: {return_dict[key]}")

def tester(x):
    print(x)
