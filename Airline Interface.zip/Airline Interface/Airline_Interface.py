#Group 1 - Project 3: Airlines Database

#Open json database file in python
#f = open('airlines_data.json','r')

import Functions as f
import json
import pprint as p
from datetime import datetime

print("Thank you for using our airlines database. Please input your data below. \n")

Name = str(input("Input user name: "))
NIM = str(input("Input user NIM: "))

y = {"user_name": Name,
     "user_NIM": NIM,
     "log_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

f.write_json(y)

print("\nAre you accessing as a user or an admin? \n")
Usertype = str(input("Type user or admin: "))
if Usertype == "user":
    print("\nType of search?")
    print("1. Search full database.")
    print("2. Search by airlines.")
    print("3. Search by airport.")
    search = int(input())

    if search == 1:
        p.pprint(f.database)
    elif search == 2:
        #Searches within json database given data.
        #print(json.dump(z))
    
        #Local variables
        Dataentry = ['' for i in range(3)]
        Datatype = ("Company name", "IATA", "ICAO")
    
        #Algorithm
        print("\nSearch by company name, IATA, and/or ICAO code. ")
        for i in range(3):
            print("Enter", Datatype[i], "data: ", end = " ")
            Dataentry[i] = input()
        f.searchtype(Dataentry)
    elif search == 3:
        #search airport airlines
        print("Airport")

elif Usertype == "admin":
    Password = str(input("Input admin password: "))
    if Password == "21344" or "23143":
        #run admin functions
        print("Admin")
    else:
        print("That was an incorrect password.")

else:
    print("Invalid input.")


