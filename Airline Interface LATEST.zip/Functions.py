#Variable and list names:

#Admin info (examples): Jason - 21344, Edensio - 23143


#Searches within json database given data.
#print(json.dump(z))
    
#Local variables
#Dataentry = ['' in range(3)]
#Datatype = ("Company name", "IATA", "ICAO")

#Algorithm
#print("Search by company name, IATA, and/or ICAO code. ")
#for i in range(3):
#    print("Enter", Datatype[i], "data: ", end = " ")
#    Dataentry[i] = input()
import json
with open('Airline_Database.json', encoding = 'utf8') as d:
    database = json.load(d)

def write_json(new_data, filename = 'logs.json'):
    with open(filename,'r+') as file:
        file_data = json.load(file)
        file_data["user_logs"].append(new_data)
        file.seek(0)
        json.dump(file_data, file, indent = 4)

def find_total_airline(airline):
    if airline in database:
            print("Planes in fleet:", database[airline]['fleet_size'])

def find_type_planes(airline):
    if airline in database:
        print("Fleet type:", database[airline]['type_of_plane'])

def find_airline_code(airline):
    if airline in database:
        print("Airline codes: \nIATA:", database[airline]['Codes'][0], "\nICAO:", database[airline]['Codes'][1])

def find_type_airline(airline):
    print("Airline type: ", database[airline]['type_of_airline'])

def find_airline_callsign(airline):
    print("Callsign: ", database[airline]['Callsign'])

def find_airport(airline):
    print("Hub airports: ", database[airline]['hub_airport'])

def find_by_airline(airline):
    if airline in database:
        print(airline + ":\n")
        find_airline_code(airline)
        find_total_airline(airline)
        find_type_planes(airline)
        find_airport(airline)
        find_destinations(airline)
        find_type_airline(airline)
        find_airline_callsign(airline)

def find_by_iata(iatacode):
    for airline in database:
        if iatacode == database[airline]['Codes'][0]:
            print(airline + ":\n")
            find_airline_code(airline)
            find_total_airline(airline)
            find_type_planes(airline)
            find_airport(airline)
            find_destinations(airline)
            find_type_airline(airline)
            find_airline_callsign(airline)

def find_by_icao(icaocode):
    for airline in database:
        if icaocode == database[airline]['Codes'][1]:
            print(airline + ":\n")
            find_airline_code(airline)
            find_total_airline(airline)
            find_type_planes(airline)
            find_airport(airline)
            find_destinations(airline)
            find_type_airline(airline)
            find_airline_callsign(airline)

def searchtype(Dataentry):
    if Dataentry[0] != "":
        find_by_airline(Dataentry[0])
    elif Dataentry[1] != "":
        find_by_iata(Dataentry[1])
    elif Dataentry[2] != "":
        find_by_icao(Dataentry[2])
    else:
        print("Invalid input.")

def find_by_airport(airport):
    print("Airline(s) operating within", airport + ":\n")
    for airline in database:
        if airport in database[airline]['hub_airport']:
            print(airline + ":\n")
            find_airline_code(airline)
            find_total_airline(airline)
            find_type_planes(airline)
            find_airport(airline)
            find_destinations(airline)
            find_type_airline(airline)
            find_airline_callsign(airline)
            print("")

def find_destinations(airline):
    print("Number of destinations: ", database[airline]['destinations'])

def printAirlines():
  for airline in database:
    print(airline)

def printKeys():
  for keys in database[selectAirline].keys():
    print(keys)