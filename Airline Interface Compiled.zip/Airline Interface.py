#Group 1 - Project 3: Airlines Database

#Open json database file in python
#f = open('airlines_data.json','r')

import Functions as f
import json
import pprint as p
from datetime import datetime
with open('Airline_Database.json', encoding = 'utf8') as d:
    database = json.load(d)

print("Thank you for using our airlines database. Please input your data below. \n")

Name = str(input("Input user name: "))
NIM = str(input("Input user NIM: "))

y = {"user_name": Name,
     "user_NIM": NIM,
     "log_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

f.write_json(y)

print("\nAre you accessing as a user or an admin? \n")
Usertype = str(input("Type user or admin: "))
if Usertype == "user":
    print("\nType of search?")
    print("1. Print full database.")
    print("2. Search by airlines.")
    print("3. Search by airport.")
    search = int(input())

    if search == 1:
        print(json.dumps(database, indent = 4))
    elif search == 2:
        #Searches within json database given data.
        #print(json.dump(z))
    
        #Local variables
        Dataentry = ['' for i in range(3)]
        Datatype = ("Company name", "IATA", "ICAO")
    
        #Algorithm
        print("\nSearch by company name, IATA, and/or ICAO code. ")
        for i in range(3):
            print("Enter", Datatype[i], "data: ", end = " ")
            Dataentry[i] = input()
        f.searchtype(Dataentry)
    elif search == 3:
        #search airport airlines
        yn = input("Print listed airports? y/n: ")
        if yn == 'y':
            print("Listed airports:\n")
            print("     1. Halim Perdanakusuma International Airport")
            print("     2. Pondok Cabe Airport")
            print("     3. Husein Sastranegara International Airport")
            print("     4. Soekarno-Hatta International Airport")
            print("     5. Surabaya Juanda Airport")
            print("     6. Kupang El Tari Airport")
            print("     7. Cijulang Nasawiru Airport")
            print("     8. Mopah International Airport")
            print("     9. Frans Kaisiepo International Airport")
            print("     10. El Tari Aiport")
            print("     11. Juwata International Airport")
            print("     12. Kualanamu International Airport")
            print("     13. Supadio International Airport")
            print("     14. Ngurah Rai Airport")
            print("     15. Syamsudin Noor Airport")
            print("     16. Sam Ratulangi International Airport")
            print("     17. Sultan Hasannudin International Airport")
            print("     18. Sultan Aji Muhammad Sulaiman Sepinggan International Airport")
        
            airport = input("\nSearch within airport: ")
            f.find_by_airport(airport)
        else:
            airport = input("\nSearch within airport: ")
            f.find_by_airport(airport)
    else:
        print("Invalid input.")

elif Usertype == "admin":
    Password = str(input("Input admin password: "))
    if Password == "21344" or "23143":
      #run admin functions
      print("Admin")
      print("\nWhat would you like to do today?")
      print("1. Add data")
      print("2. Remove data")
      print("3. Modify existing data")
      adminChoice = int(input(print("Enter choice number: ", end = "")))
      print("\n", end = "")

      # lets admin add new data
      if adminChoice == 1:
        f.printAirlines()
        selectAirline = input(print("Which airline's data would you like to change?: ", end = ""))
        print("\n", end = "")
  
        print("List of data types in the database")
        f.printKeys()
        selectKey = input(print("Which of the data above would you like to change?: ", end = ""))
        print("\n", end = "")

        # determines whether data type is a list/string
        if type(database[selectAirline][selectKey]) == list:
          for element in database[selectAirline][selectKey]:
            print(element)
          userInput = input("Enter the new " + selectKey + ": ")
          database[selectAirline][selectKey].append(userInput)
        else:
          print(database[selectAirline][selectKey])
          userInput = input("Enter the new " + selectKey + ": ")
          # creates a list to append the newly added data
          database[selectAirline][selectKey] = [database[selectAirline][selectKey]]
          database[selectAirline][selectKey].append(userInput)
  
        # test print
        print("\n" + str(database[selectAirline][selectKey]))

      elif adminChoice == 2:
        # lets admin remove data
        f.printAirlines()
        selectAirline = input(print("Which airline's data would you like to change?: ", end = ""))
        print("\n", end = "")

        print("List of data types in the database:")
        f.printKeys()
        selectKey = input(print("Which of the data above would you like to change?: ", end = ""))
        print("\n", end = "")

        # determines whether data type is a list/string
        if type(database[selectAirline][selectKey]) == list:
          for element in database[selectAirline][selectKey]:
            print(element)
          userInput = input("Enter the data that would be removed from " + selectKey + ": ")
          database[selectAirline][selectKey].remove(userInput)
        else:
          # if data type contains only one string, turns into an empty string
          database[selectAirline][selectKey] = ""
  
        # test print
        print("\n" + str(database[selectAirline][selectKey]))

      elif adminChoice == 3:
        # lets admin to modify existing data
        f.printAirlines()
        selectAirline = input(print("Which airline's data would you like to change?: ", end = ""))
        print("\n", end = "")
  
        print("List of data types in the database:")
        f.printKeys()
        selectKey = input(print("Which of the data above would you like to change?: ", end = ""))
        print("\n", end = "")

        # determines whether data type is a list/string
        if type(database[selectAirline][selectKey]) == list:
          for element in database[selectAirline][selectKey]:
            print(element)
          userInput = input("Enter the data that would be replaced in " + selectKey + ": ")

          for items, index in enumerate(database[selectAirline][selectKey]):
            if(index == userInput):
              indexTarget = items
    
          userInputNew = input("Enter the new data that would replace " + userInput + ": ")

          database[selectAirline][selectKey].remove(userInput)
          database[selectAirline][selectKey].insert(indexTarget, userInputNew)
        else:
          # if data type contains only one string, new value replaces old value
          print(database[selectAirline][selectKey])
          userInput = input("Enter the data that would be replace " + str(database[selectAirline][selectKey]) + ": ")
          database[selectAirline][selectKey] = userInput
  
        # test print
        print(database[selectAirline][selectKey])

      else:
        print("Invalid Input!")

    else:
        print("That was an incorrect password.")

else:
    print("Invalid input.")
