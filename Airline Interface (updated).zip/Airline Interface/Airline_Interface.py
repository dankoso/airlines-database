#Group 1 - Project 3: Airlines Database

#Open json database file in python
#f = open('airlines_data.json','r')

import Functions as f
import json
import pprint as p
from datetime import datetime
with open('Airline_Database.json', encoding = 'utf8') as d:
    database = json.load(d)

print("Thank you for using our airlines database. Please input your data below. \n")

Name = str(input("Input user name: "))
NIM = str(input("Input user NIM: "))

y = {"user_name": Name,
     "user_NIM": NIM,
     "log_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }

f.write_json(y)

print("\nAre you accessing as a user or an admin? \n")
Usertype = str(input("Type user or admin: "))
if Usertype == "user":
    print("\nType of search?")
    print("1. Print full database.")
    print("2. Search by airlines.")
    print("3. Search by airport.")
    search = int(input())

    if search == 1:
        print(json.dumps(database, indent = 4))
    elif search == 2:
        #Searches within json database given data.
        #print(json.dump(z))
    
        #Local variables
        Dataentry = ['' for i in range(3)]
        Datatype = ("Company name", "IATA", "ICAO")
    
        #Algorithm
        print("\nSearch by company name, IATA, and/or ICAO code. ")
        for i in range(3):
            print("Enter", Datatype[i], "data: ", end = " ")
            Dataentry[i] = input()
        f.searchtype(Dataentry)
    elif search == 3:
        #search airport airlines
        yn = input("Print listed airports? y/n: ")
        if yn == 'y':
            print("Listed airports:\n")
            print("     1. Halim Perdanakusuma International Airport")
            print("     2. Pondok Cabe Airport")
            print("     3. Husein Sastranegara International Airport")
            print("     4. Soekarno-Hatta International Airport")
            print("     5. Surabaya Juanda Airport")
            print("     6. Kupang El Tari Airport")
            print("     7. Cijulang Nasawiru Airport")
            print("     8. Mopah International Airport")
            print("     9. Frans Kaisiepo International Airport")
            print("     10. El Tari Aiport")
            print("     11. Juwata International Airport")
            print("     12. Kualanamu International Airport")
            print("     13. Supadio International Airport")
            print("     14. Ngurah Rai Airport")
            print("     15. Syamsudin Noor Airport")
            print("     16. Sam Ratulangi International Airport")
            print("     17. Sultan Hasannudin International Airport")
            print("     18. Sultan Aji Muhammad Sulaiman Sepinggan International Airport")
        
            airport = input("\nSearch within airport: ")
            f.find_by_airport(airport)
        else:
            airport = input("\nSearch within airport: ")
            f.find_by_airport(airport)
    else:
        print("Invalid input.")

elif Usertype == "admin":
    Password = str(input("Input admin password: "))
    if Password == "21344" or "23143":
        #run admin functions
        print("Admin")
    else:
        print("That was an incorrect password.")

else:
    print("Invalid input.")


